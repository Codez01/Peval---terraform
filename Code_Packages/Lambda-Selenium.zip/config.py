import configparser

config = configparser.ConfigParser()
config.read('etc/config.properties')
